package model;

public interface IntModel {

		void executeCommand(String actionCommand);
		String getData();

}
